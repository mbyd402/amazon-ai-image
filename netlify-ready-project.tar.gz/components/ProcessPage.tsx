'use client'

import { useState, useRef } from 'react'

interface ProcessPageProps {
  operation: 'background' | 'watermark' | 'upscale' | 'compliance'
  userId: string
  remainingPoints: number
}

type OperationType = ProcessPageProps['operation']

const getOperationLabel = (operation: OperationType) => {
  switch (operation) {
    case 'background': return 'AI White Background'
    case 'watermark': return 'Remove Watermark / Text / Logo'
    case 'upscale': return 'AI Upscale & Enhance'
    case 'compliance': return 'Amazon Compliance Check'
  }
}

export default function ProcessPage({ operation, userId, remainingPoints }: ProcessPageProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [processing, setProcessing] = useState(false)
  const [processedUrls, setProcessedUrls] = useState<string[]>([])
  const [error, setError] = useState<string>('')
  const [watermarkSelection, setWatermarkSelection] = useState<{x: number, y: number, width: number, height: number} | null>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFiles = Array.from(e.target.files || [])
    const combinedFiles = [...selectedFiles, ...newFiles]
    
    if (combinedFiles.length > 5) {
      setError('Maximum 5 images per batch. Please process in batches.')
      return
    }

    // Check points
    if (combinedFiles.length > remainingPoints) {
      setError(`You only have ${remainingPoints} points left. Please buy more points.`)
      return
    }

    setSelectedFiles(combinedFiles)
    setError('')
    setProcessedUrls([])
    
    // Generate previews for new files only
    const newPreviews = [...previews, ...newFiles.map(file => URL.createObjectURL(file))]
    setPreviews(newPreviews)
    
    // Reset input so the same file can be added again
    e.target.value = ''
  }

  const removeFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index)
    const newPreviews = previews.filter((_, i) => i !== index)
    setSelectedFiles(newFiles)
    setPreviews(newPreviews)
  }

  const processImage = async (file: File, index: number): Promise<string> => {
    const formData = new FormData()
    formData.append('image', file)
    formData.append('operation', operation)
    formData.append('userId', userId)

    if (operation === 'watermark' && watermarkSelection) {
      formData.append('selection', JSON.stringify(watermarkSelection))
    }

    const response = await fetch('/api/process', {
      method: 'POST',
      body: formData,
    })

    if (!response.ok) {
      const err = await response.json()
      throw new Error(err.error || 'Processing failed')
    }

    const data = await response.json()
    // We now get base64 from API instead of URL - use data URL directly
    if (data.processedBase64) {
      const mimeType = data.mimeType || 'image/png'
      return `data:${mimeType};base64,${data.processedBase64}`
    }
    return data.processedUrl
  }

  const handleProcess = async () => {
    if (selectedFiles.length === 0) {
      setError('Please select at least one image')
      return
    }

    if (selectedFiles.length > remainingPoints && operation !== 'compliance') {
      setError(`Not enough points. You need ${selectedFiles.length} points but only have ${remainingPoints}.`)
      return
    }

    setProcessing(true)
    setError('')
    setProcessedUrls([])

    try {
      const urls: string[] = []
      for (let i = 0; i < selectedFiles.length; i++) {
        const url = await processImage(selectedFiles[i], i)
        urls.push(url)
      }
      setProcessedUrls(urls)
      
      // Don't need to reload - points will refresh on next page load
      // User can see processed results immediately
    } catch (err: any) {
      setError(err.message)
    } finally {
      setProcessing(false)
    }
  }

  const handleDownloadAll = () => {
    processedUrls.forEach((url, index) => {
      const a = document.createElement('a')
      a.href = url
      a.download = `processed-${selectedFiles[index].name}`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
    })
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        {getOperationLabel(operation)}
      </h2>

      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-600 rounded-md p-3 text-sm">
          {error}
        </div>
      )}

      {/* Hidden File Input - triggered by + button or initial upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Initial Upload Button - only show when no images selected */}
      {previews.length === 0 && (
        <div className="mb-6">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-12 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex flex-col items-center justify-center text-gray-500 hover:text-blue-500 hover:border-blue-500 transition-colors"
          >
            <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <span className="text-lg font-medium">Click to upload images</span>
            <span className="text-sm text-gray-400 mt-1">Max 5 images per batch</span>
          </button>
        </div>
      )}

      {/* Preview Grid */}
      {previews.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            Selected Images ({previews.length}/5)
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {previews.map((preview, index) => (
              <div key={index} className="relative group">
                <img
                  src={preview}
                  alt={`Preview ${index + 1}`}
                  className="w-full h-32 object-cover rounded-lg border border-gray-200 dark:border-gray-700"
                />
                <button
                  onClick={() => removeFile(index)}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  ×
                </button>
              </div>
            ))}
            {/* Add more button - only show if less than 5 images */}
            {previews.length < 5 && (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-32 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 flex flex-col items-center justify-center text-gray-400 hover:text-blue-500 hover:border-blue-500 transition-colors"
              >
                <svg className="w-8 h-8 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                <span className="text-sm">Add</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Watermark selection canvas for single image */}
      {operation === 'watermark' && previews.length === 1 && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Draw a box over the watermark/text you want to remove
          </h3>
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg inline-block">
            <img
              ref={imageRef}
              src={previews[0]}
              alt="To process"
              className="max-w-full h-auto rounded"
              onLoad={() => {
                // Canvas setup for selection
                if (canvasRef.current && imageRef.current) {
                  canvasRef.current.width = imageRef.current.naturalWidth
                  canvasRef.current.height = imageRef.current.naturalHeight
                }
              }}
            />
          </div>
          {watermarkSelection && (
            <p className="mt-2 text-sm text-green-600">
              ✓ Selection created. You can adjust by drawing again.
            </p>
          )}
        </div>
      )}

      {/* Process Button */}
      <div className="flex items-center space-x-4">
        <button
          onClick={handleProcess}
          disabled={processing || selectedFiles.length === 0}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {processing ? 'Processing...' : `Process ${selectedFiles.length} Image${selectedFiles.length !== 1 ? 's' : ''} (${selectedFiles.length} point${selectedFiles.length !== 1 ? 's' : ''})`}
        </button>
        {operation !== 'compliance' && (
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {remainingPoints} points remaining
          </span>
        )}
      </div>

      {/* Processed Results */}
      {processedUrls.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Processed Results
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
            {processedUrls.map((url, index) => (
              <div key={index} className="relative">
                <img
                  src={url}
                  alt={`Processed ${index + 1}`}
                  className="w-full h-auto max-h-96 object-contain rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800"
                />
                <div className="mt-2 flex justify-end">
                  <a
                    href={url}
                    download={`processed-${selectedFiles[index].name}`}
                    className="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                  >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Download Image
                  </a>
                </div>
              </div>
            ))}
          </div>
          {processedUrls.length > 1 && (
            <button
              onClick={handleDownloadAll}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
            >
              Download All
            </button>
          )}
        </div>
      )}

      {/* Instructions */}
      <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-md">
        <h3 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-1">
          Instructions
        </h3>
        {operation === 'background' && (
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Upload your product image, and we will automatically remove the background and replace it with pure white (RGB 255,255,255) that meets Amazon's requirements.
          </p>
        )}
        {operation === 'watermark' && (
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Upload your image, draw a box over the watermark, text, or logo you want to remove, and AI will automatically remove it and repair the background.
          </p>
        )}
        {operation === 'upscale' && (
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Upscale your image by 2x or 4x with AI enhancement to meet Amazon's 1000px minimum requirement for zoom functionality.
          </p>
        )}
        {operation === 'compliance' && (
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Check if your main image meets Amazon's policies. We check for pure background, extra text/watermark, size requirement, and other common violations. Compliance check is free!
          </p>
        )}
      </div>
    </div>
  )
}
